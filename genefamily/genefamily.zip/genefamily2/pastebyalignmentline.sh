#!/bin/bash

paste -d "" "Gfagenome_ind_"{1..50}"_aligned.fnawocr" > myco_concatenatedalignment.fna

